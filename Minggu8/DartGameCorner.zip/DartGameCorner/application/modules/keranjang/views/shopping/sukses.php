<h2>Proses Order sukses</h2>
<div class="kotak2">
    <p>Terima kasih sudah berbelanja di toko Komang.My.ID Shop. Order
        anda sudah masuk ke database kami, dan dalam 3 x 24 Jam barang
        akan sampai di tempat anda.<br>
        Jangan segan mengontak kami jika ada permasalahan!</p>
</div>