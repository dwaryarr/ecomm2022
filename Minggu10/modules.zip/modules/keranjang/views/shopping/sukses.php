<!-- Main Frame -->
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <!-- <h1 class="mt-4"><?= $judul ?></h1> -->
            <h1 class="mt-4">Proses Order Sukses</h1>
            <div class="row mt-4">
                <div class="kotak2">
                    <p>Terima kasih sudah berbelanja di toko DartGameCorner. Order
                        anda sudah masuk ke database kami, dan dalam 3 x 24 Jam produk
                        akan diterima oleh anda.<br>
                        Jangan segan mengontak kami jika ada permasalahan!</p>
                </div>
            </div>
        </div>