</div>
<!-- /.row -->
</div>
<!-- /.col-lg-9 -->


</div>
<!-- /.row -->

</div>
<footer class="footer">
    <div class="container">
        <p class="text-muted">
            <center>Contoh Shopping Cart dengan CodeIgniter dan Bootstrap. By:<a href="http://www.komang.my.id"> Komang.My.ID</a></center>
        </p>
    </div>
</footer>

<!-- Bootstrap core JavaScript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url() ?>assets/jquery/jquery-3.2.1.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/arf.js"></script>
<script src="<?php echo base_url() ?>assets/js/prs.js"></script>
<script src="<?php echo base_url() ?>assets/js/validation.js"></script>
<script src="<?php echo base_url() ?>assets/jquery/jquery-ui.js"></script>
<script src="<?php echo base_url() ?>assets/jquery/jquery.validate.min.js"></script>
<script>
    window.jQuery || document.write('<script src="<?php echo base_url() ?>assets/vendor/jquery.min.js"><\/script>')
</script>
<script src="<?php echo base_url() ?>assets/bootstrap/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="<?php echo base_url() ?>assets/asie/js/ie10-viewport-bug-workaround.js"></script>
</body>

</html>